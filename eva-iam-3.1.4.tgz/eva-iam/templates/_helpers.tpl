{{/*
Expand the name of the chart.
*/}}
{{- define "eva-iam.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "eva-iam.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "eva-iam.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "eva-iam.labels" -}}
helm.sh/chart: {{ include "eva-iam.chart" . }}
{{ include "eva-iam.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "eva-iam.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eva-iam.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "eva-iam.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "eva-iam.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Name of the shared PersistentVolume (see templates/persistVolume.yaml).
*/}}
{{- define "eva-iam.pv.name" -}}
{{- printf "%s-data" (include "eva-iam.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Name of the shared PersistentVolumeClaim (see templates/persistVolume.yaml), mounted by
postgres/keycloak/redis via a per-component subPath.
*/}}
{{- define "eva-iam.pvc.name" -}}
{{- printf "%s-data" (include "eva-iam.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Define secret name
*/}}
{{- define "eva-iam.secret.name" -}}
{{- if and .Values.secret .Values.secret.nameOverride }}
{{- .Values.secret.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-secret" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}


{{/*
Define tls secret name
*/}}
{{- define "eva-iam.tlsSecret.name" -}}
{{- if .Values.ingress.tls.secretNameOverride }}
{{- .Values.ingress.tls.secretNameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-secret-tls" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}



{{/*
Public base URL that eva-iam is reachable at. By default this is derived as
https://<config.host><ingress.path>, or https://<config.host>:<config.publicPort><ingress.path>
when config.publicPort is set. It can still be overridden completely with config.publicUrl for
environments that need a fully custom external URL. Keycloak's hostname/admin URL and the
dispatcher's OIDC issuer/JWKS URL derive from this, while the ingress host still uses config.host.
*/}}
{{- define "eva-iam.baseUrl" -}}
{{- if .Values.config.publicUrl }}
{{- .Values.config.publicUrl | trimSuffix "/" }}
{{- else if .Values.config.publicPort }}
{{- printf "https://%s:%v%s" .Values.config.host .Values.config.publicPort (.Values.ingress.path | trimSuffix "/") }}
{{- else }}
{{- printf "https://%s%s" .Values.config.host (.Values.ingress.path | trimSuffix "/") }}
{{- end }}
{{- end }}

{{/*
Define imagePullSecret name
*/}}
{{- define "eva-iam.imagePullSecret.name" -}}
{{- if .Values.imagePullSecrets.nameOverride }}
{{- .Values.imagePullSecrets.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-secret-regcred" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
imagePullSecrets key + list for a pod spec (replaces the "imagePullSecrets:" line too). Usage:
  {{- include "eva-iam.imagePullSecrets" . | nindent 6 }}
*/}}
{{- define "eva-iam.imagePullSecrets" -}}
{{- if .Values.imagePullSecrets.enabled }}
{{- if .Values.imagePullSecrets.ExistingSecret }}
{{- printf "- name: %s" .Values.imagePullSecrets.ExistingSecret }}
{{- else if .Values.imagePullSecrets.create }}
{{- printf "- name: %s" (include "eva-iam.imagePullSecret.name" .) }}
{{- end }}
{{- end }}
{{- end }}