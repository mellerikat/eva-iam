{{/*
Define dispatcher name
*/}}
{{- define "eva-iam.dispatcher.name" -}}
{{- printf "%s-dispatcher" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Common labels
*/}}
{{- define "eva-iam.dispatcher.labels" -}}
helm.sh/chart: {{ include "eva-iam.chart" . }}
{{ include "eva-iam.dispatcher.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "eva-iam.dispatcher.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eva-iam.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
component: eva-iam-dispatcher
{{- end }}


{{/*
Create the name of the internal service to use
*/}}
{{- define "eva-iam.dispatcher.svc.internal.name" -}}
{{- printf "%s-dispatcher-internal" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
