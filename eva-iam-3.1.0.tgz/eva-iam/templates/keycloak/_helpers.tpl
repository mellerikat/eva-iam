{{/*
Define keycloak name
*/}}
{{- define "eva-iam.keycloak.name" -}}
{{- printf "%s-keycloak" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Common labels
*/}}
{{- define "eva-iam.keycloak.labels" -}}
helm.sh/chart: {{ include "eva-iam.chart" . }}
{{ include "eva-iam.keycloak.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "eva-iam.keycloak.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eva-iam.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
component: eva-iam-keycloak
{{- end }}


{{/*
Create the name of the internal service to use
*/}}    
{{- define "eva-iam.keycloak.svc.internal.name" -}}
{{- printf "%s-keycloak-internal" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}