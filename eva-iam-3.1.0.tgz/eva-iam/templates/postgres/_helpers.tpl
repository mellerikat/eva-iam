{{/*
Define postgres name
*/}}
{{- define "eva-iam.postgres.name" -}}
{{- printf "%s-postgres" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Common labels
*/}}
{{- define "eva-iam.postgres.labels" -}}
helm.sh/chart: {{ include "eva-iam.chart" . }}
{{ include "eva-iam.postgres.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "eva-iam.postgres.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eva-iam.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
component: eva-iam-postgres
{{- end }}


{{/*
Create the name of the internal service to use
*/}}    
{{- define "eva-iam.postgres.svc.internal.name" -}}
{{- printf "%s-postgres-internal" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}