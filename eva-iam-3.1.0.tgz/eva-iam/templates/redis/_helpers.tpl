{{/*
Define redis name
*/}}
{{- define "eva-iam.redis.name" -}}
{{- printf "%s-redis" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Common labels
*/}}
{{- define "eva-iam.redis.labels" -}}
helm.sh/chart: {{ include "eva-iam.chart" . }}
{{ include "eva-iam.redis.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "eva-iam.redis.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eva-iam.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
component: eva-iam-redis
{{- end }}


{{/*
Create the name of the internal service to use
*/}}
{{- define "eva-iam.redis.svc.internal.name" -}}
{{- printf "%s-redis-internal" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
